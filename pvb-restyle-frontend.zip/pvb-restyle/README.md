# PVB Examenafspraken — frontend restyle (origineel ontwerp)

Volledig nieuw, origineel ontwerp voor de bestaande React + Tailwind frontend
(React 18 + Vite, Tailwind CSS, React Router v6, Axios — zoals in je documentatie).

**Richting:** servicedesk/ticket-esthetiek, passend bij de ICT-support context van de
opleiding. Carbon-donkere sidebar met een dunne "geperforeerde" rand (ticketmotief),
amber als actiekleur, monospace voor ticketnummers/codes/stappen, Space Grotesk voor
koppen. Donker is standaard; Licht is te kiezen via de knop, onthouden in `localStorage`.

Geen van de kleuren, tokens of naamgeving is overgenomen uit het eerder aangeleverde
pakket — dit is een zelfstandig, nieuw paletje speciaal voor deze app.

---

## 1. Installeren

Eén nieuwe dependency (de rest heb je al):

```bash
npm install lucide-react
```

Als Tailwind nog niet draait:

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

## 2. Bestanden overzetten

Kopieer de inhoud van deze map over je `frontend/` heen — de mappen komen 1-op-1 overeen:

| Bestand hier | Doel in jouw project |
|---|---|
| `tailwind.config.js` | project root (merge de `theme.extend` als je al een config hebt) |
| `src/index.css` | `src/index.css` (of waar je Tailwind importeert) |
| `src/context/ThemeContext.jsx` | naast je `AuthContext.jsx` |
| `src/components/ThemeToggle.jsx` | `src/components/` |
| `src/components/Layout.jsx` | `src/components/` (vervangt/absorbeert `Navbar.jsx`) |
| `src/components/Badge.jsx` | `src/components/` |
| `src/pages/Login.jsx` | `src/pages/Login.jsx` |
| `src/pages/Dashboard.jsx` | `src/pages/Dashboard.jsx` |
| `src/pages/FormulierInvullen.jsx` | `src/pages/FormulierInvullen.jsx` |
| `src/pages/DocentDashboard.jsx` | `src/pages/DocentDashboard.jsx` |
| `src/pages/OpdrachtenBeheer.jsx` | `src/pages/OpdrachtenBeheer.jsx` |
| `src/assets/pvb-logo.png` | `src/assets/pvb-logo.png` (je bestaande PVB-logo, ongewijzigd) |

## 3. ThemeProvider inhangen

In `src/main.jsx`, wikkel je app in de `ThemeProvider` (buiten je `AuthProvider`):

```jsx
import { ThemeProvider } from './context/ThemeContext';

ReactDOM.createRoot(document.getElementById('root')).render(
  <ThemeProvider>
    <AuthProvider>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </AuthProvider>
  </ThemeProvider>
);
```

Meer is niet nodig — `dark:`-klassen door de hele app volgen automatisch.

## 4. API-calls aansluiten

De pagina's tonen voorbeelddata als fallback zodat ze meteen renderen. Op de plekken
met een `// GET /api/...`-comment hang je je echte Axios-call in. Ze verwijzen naar je
bestaande endpoints:

- `Dashboard.jsx` → `GET /api/formulieren/mijn` en download via `GET /api/formulieren/:id/export/docx`
- `FormulierInvullen.jsx` → `GET /api/opdrachten` + `POST /api/formulieren`
- `DocentDashboard.jsx` → `GET /api/formulieren/alle`
- `OpdrachtenBeheer.jsx` → `GET /api/opdrachten/beheer`, `POST/PUT/DELETE /api/opdrachten/:id`
- Login-knop → `href="/api/auth/login"` (OIDC), uitloggen → `/api/auth/logout`

Zodra de echte data binnenkomt, verdwijnt de voorbeelddata vanzelf (de fallback vult
alleen als de array leeg is — haal die `sample`/fallback-blokken weg zodra je live bent).

## 5. Design tokens

Alle kleuren staan in `tailwind.config.js`:

| Token | Hex | Gebruik |
|---|---|---|
| `carbon` | `#181C1E` | sidebar, donkere achtergrond |
| `paper` | `#EEF1EE` | lichte achtergrond |
| `ink-900/700/500` | grijs-groen tinten | tekst |
| `amber` | `#E2962F` | actieknoppen, focus, "concept"-status |
| `moss` | `#4C8C5B` | "gedownload/actief"-status |
| `rust` | `#B85C38` | "ingeleverd"-status |

Gebruik deze namen in plaats van losse hex-waarden voor consistentie.

**Let op:** je bestaande `pvb-logo.png` (groen PVB-beeldmerk met ondertekst) is gewoon
hergebruikt — die had geen relatie met het eerdere, ingetrokken kleurenpakket.
