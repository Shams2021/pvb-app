/**
 * Statusindicator, gestyled als een systeem-LED in plaats van een gekleurd label —
 * past bij het servicedesk/ticket-karakter van de app.
 * Gebruik: <Badge status="gedownload" /> of <Badge>Actief</Badge>
 */
const MAP = {
  gedownload: { label: 'Gedownload', dot: 'bg-moss', text: 'text-ink-700 dark:text-white/75' },
  concept: { label: 'Concept', dot: 'bg-amber', text: 'text-ink-700 dark:text-white/75' },
  ingeleverd: { label: 'Ingeleverd', dot: 'bg-rust', text: 'text-ink-700 dark:text-white/75' },
  actief: { label: 'Actief', dot: 'bg-moss', text: 'text-ink-700 dark:text-white/75' },
  inactief: { label: 'Inactief', dot: 'bg-ink-500/50 dark:bg-white/25', text: 'text-ink-500 dark:text-white/45' },
};

export default function Badge({ status, children }) {
  const m = MAP[status] || { label: children, dot: 'bg-amber', text: 'text-ink-700 dark:text-white/75' };
  return (
    <span className={`inline-flex items-center gap-1.5 font-mono text-[11px] font-medium uppercase tracking-wide ${m.text}`}>
      <span className={`h-[7px] w-[7px] rounded-full ${m.dot}`} />
      {children || m.label}
    </span>
  );
}
