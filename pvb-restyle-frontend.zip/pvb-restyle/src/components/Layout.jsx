import { NavLink } from 'react-router-dom';
import {
  ClipboardCheck, FileCheck2, CircleHelp, Table2, ListChecks, Users, LogOut,
} from 'lucide-react';
import logo from '../assets/pvb-logo.png';
import ThemeToggle from './ThemeToggle';

/**
 * App-shell: donkere carbon-sidebar (altijd donker, in beide thema's) + een werkvlak
 * dat wisselt tussen licht (#EEF1EE) en donker (carbon). De sidebar heeft een dunne
 * "geperforeerde" rand rechts — een knipoog naar de ticket/formulier-aard van de app.
 *
 * Props:
 *   role   — 'student' | 'docent'   (bepaalt welke navigatie-items tonen)
 *   title  — string, getoond in de topbalk
 *   right  — optioneel element uiterst rechts in de topbalk (bijv. een "Nieuw"-knop)
 *   user   — { naam, rol, initials } voor de sidebar-footer
 */
const studentNav = [
  { to: '/', icon: FileCheck2, label: 'Mijn afspraken', end: true },
  { to: '/hoe-werkt-het', icon: CircleHelp, label: 'Hoe werkt het?' },
];
const docentNav = [
  { to: '/docent', icon: Table2, label: 'Formulieren', end: true },
  { to: '/docent/opdrachten', icon: ListChecks, label: 'Opdrachten' },
  { to: '/docent/gebruikers', icon: Users, label: 'Gebruikers' },
];

function NavItem({ to, icon: Icon, label, end }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `flex items-center gap-2.5 rounded px-2.5 py-2.5 text-[13px] transition-colors duration-150 ease-crisp ${
          isActive
            ? 'bg-amber/15 font-semibold text-amber'
            : 'font-medium text-white/65 hover:text-white'
        }`
      }
    >
      <Icon size={17} strokeWidth={1.75} /> {label}
    </NavLink>
  );
}

export default function Layout({ role = 'student', title, right, user, children }) {
  const nav = role === 'docent' ? docentNav : studentNav;
  const u = user || { naam: 'Bes Ternava', rol: role, initials: 'BT' };

  return (
    <div className="grid h-screen grid-cols-[236px_1fr] overflow-hidden font-sans">
      {/* Sidebar — altijd carbon, met geperforeerde rand rechts (signatuurelement) */}
      <aside className="relative flex flex-col bg-carbon px-3.5 py-4">
        <div className="pointer-events-none absolute right-0 top-0 h-full w-px bg-perforation" />

        <div className="flex items-center gap-3 px-2 pb-5 pt-1.5">
          <img src={logo} alt="PVB" className="h-9 w-9 rounded bg-white object-contain" />
          <div>
            <div className="font-display text-sm font-bold leading-none text-white">PVB</div>
            <div className="mt-1 font-mono text-[10px] tracking-wide text-white/40">Examenafspraken</div>
          </div>
        </div>

        <div className="px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-white/35">
          {role === 'docent' ? 'Docent' : 'Student'}
        </div>

        <nav className="flex flex-col gap-0.5">
          {nav.map((n) => <NavItem key={n.to} {...n} />)}
        </nav>

        <div className="mt-auto flex items-center gap-2.5 border-t border-white/10 pt-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-amber/40 font-mono text-[11px] font-semibold text-amber">
            {u.initials}
          </span>
          <div className="min-w-0 flex-1">
            <div className="truncate text-xs font-semibold text-white">{u.naam}</div>
            <div className="text-[11px] capitalize text-white/45">{u.rol}</div>
          </div>
          {/* GET /api/auth/logout */}
          <a href="/api/auth/logout" aria-label="Uitloggen">
            <LogOut size={16} strokeWidth={1.75} className="text-white/45 hover:text-white" />
          </a>
        </div>
      </aside>

      {/* Werkvlak — wisselt licht/donker */}
      <div className="flex flex-col overflow-hidden bg-paper transition-colors duration-200 ease-crisp dark:bg-carbon">
        <header className="flex h-[60px] flex-shrink-0 items-center justify-between border-b border-ink-900/8 bg-white/90 px-8 backdrop-blur dark:border-white/8 dark:bg-carbon-800/70">
          <h1 className="font-display text-[17px] font-bold text-ink-900 dark:text-white">{title}</h1>
          <div className="flex items-center gap-4">
            {right}
            <ThemeToggle />
          </div>
        </header>
        <main className="flex-1 overflow-auto p-8">{children}</main>
      </div>
    </div>
  );
}
