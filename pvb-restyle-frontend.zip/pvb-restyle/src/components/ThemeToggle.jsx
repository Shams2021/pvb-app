import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

/** Segmented Licht / Donker schakelaar. In de topbalk en op het inlogscherm. */
export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const base =
    'inline-flex items-center gap-1.5 rounded px-3 py-1.5 font-mono text-[11px] font-medium uppercase tracking-wide transition-all duration-150 ease-crisp';
  const active = 'bg-amber text-carbon-900';
  const idle = 'text-ink-500 dark:text-white/45 hover:text-ink-900 dark:hover:text-white';

  return (
    <div className="inline-flex rounded-md border border-ink-900/10 bg-black/[0.03] p-[3px] dark:border-white/10 dark:bg-white/[0.04]">
      <button
        type="button"
        onClick={() => setTheme('light')}
        className={`${base} ${theme === 'light' ? active : idle}`}
      >
        <Sun size={13} /> Licht
      </button>
      <button
        type="button"
        onClick={() => setTheme('dark')}
        className={`${base} ${theme === 'dark' ? active : idle}`}
      >
        <Moon size={13} /> Donker
      </button>
    </div>
  );
}
