import { createContext, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext({ theme: 'dark', setTheme: () => {} });

/**
 * Wrap de hele app in <ThemeProvider> (in main.jsx, om <AuthProvider> heen).
 * - Donker is de standaard voor nieuwe bezoekers.
 * - De keuze wordt onthouden in localStorage onder 'pvb-theme'.
 * - Wisselen zet/verwijdert de `dark` class op <html>, die alle Tailwind
 *   `dark:`-varianten in de app aanstuurt.
 */
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    if (typeof window === 'undefined') return 'dark';
    return localStorage.getItem('pvb-theme') || 'dark';
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('pvb-theme', theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
