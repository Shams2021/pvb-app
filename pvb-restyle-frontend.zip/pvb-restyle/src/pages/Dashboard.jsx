import { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Plus, FilePlus2, FileCheck2, FilePenLine, CheckCheck, Download, Trash2,
  ArrowRight, Eye,
} from 'lucide-react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';

const NieuwBtn = (
  <a
    href="/formulier/nieuw"
    className="inline-flex items-center gap-2 rounded bg-amber px-4 py-2 text-sm font-semibold text-carbon-900 transition-all duration-150 ease-crisp hover:bg-amber-600"
  >
    <Plus size={17} strokeWidth={2} /> Nieuw formulier
  </a>
);

const cardCls =
  'rounded-lg border border-ink-900/8 bg-white p-5 transition-colors duration-200 ease-crisp dark:border-white/8 dark:bg-white/[0.03]';

export default function Dashboard() {
  const [formulieren, setFormulieren] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // GET /api/formulieren/mijn
    axios
      .get('/api/formulieren/mijn')
      .then((r) => setFormulieren(r.data))
      .catch(() => setFormulieren([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Layout role="student" title="Mijn examenafspraken" right={NieuwBtn}>
      <p className="eyebrow mb-1">B1-K1 · ICT system engineer</p>

      {!loading && formulieren.length === 0 ? <EmptyState /> : <FormulierList items={formulieren} />}
    </Layout>
  );
}

/* ---------- Lege staat ---------- */
function EmptyState() {
  const steps = [
    { n: 1, t: 'Vul het formulier in', s: 'W1, W2 en W3.' },
    { n: 2, t: 'Download als Word', s: 'Officieel formulier.' },
    { n: 3, t: 'Onderteken & lever in', s: 'Via Canvas.' },
  ];
  return (
    <div className={`${cardCls} mx-auto mt-4 flex max-w-2xl flex-col items-center p-11 text-center`}>
      <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-amber/40 text-amber">
        <FilePlus2 size={26} strokeWidth={1.75} />
      </span>
      <h2 className="mb-2 font-display text-xl font-bold text-ink-900 dark:text-white">Nog geen examenafspraken</h2>
      <p className="mb-5 max-w-md text-sm leading-relaxed text-ink-700 dark:text-white/65">
        Stel je eerste formulier op voor je Proeve van Bekwaamheid. Het duurt ongeveer 10 minuten.
      </p>
      <a
        href="/formulier/nieuw"
        className="inline-flex items-center gap-2 rounded bg-amber px-5 py-3 font-semibold text-carbon-900 transition-all hover:bg-amber-600"
      >
        <Plus size={19} strokeWidth={2} /> Maak je eerste formulier
      </a>
      <div className="mt-8 flex w-full gap-3 text-left">
        {steps.map((st) => (
          <div key={st.n} className="flex-1 rounded border border-ink-900/8 bg-paper p-4 dark:border-white/8 dark:bg-white/[0.02]">
            <span className="inline-flex h-6 w-6 items-center justify-center rounded border border-amber/40 font-mono text-[11px] font-semibold text-amber">
              {st.n}
            </span>
            <div className="mt-2.5 text-[13px] font-semibold text-ink-900 dark:text-white">{st.t}</div>
            <div className="mt-0.5 text-xs text-ink-500 dark:text-white/45">{st.s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Gevulde lijst ---------- */
const ICONS = {
  gedownload: FileCheck2,
  concept: FilePenLine,
  ingeleverd: CheckCheck,
};

function FormulierList({ items }) {
  // Voorbeelddata zodat het scherm meteen rendert voordat de API is aangesloten.
  const rows = items.length
    ? items
    : [
        { id: 1, ticket: 'PVB-2026-0112', titel: 'Examenafspraak — periode 3', sub: 'Aangemaakt 28 jun 2026 · Beoordelaar: R. de Vries', status: 'gedownload' },
        { id: 2, ticket: 'PVB-2026-0141', titel: 'Examenafspraak — herkansing W2', sub: 'Aangemaakt 1 jul 2026 · Nog niet compleet', status: 'concept' },
        { id: 3, ticket: 'PVB-2026-0087', titel: 'Examenafspraak — periode 2', sub: 'Ingeleverd via Canvas · 12 mei 2026', status: 'ingeleverd' },
      ];

  return (
    <div className="mt-4 flex flex-col gap-3">
      {rows.map((f) => {
        const Icon = ICONS[f.status] || FilePenLine;
        return (
          <div key={f.id} className={`${cardCls} flex items-center gap-5`}>
            <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded border border-ink-900/10 text-ink-700 dark:border-white/10 dark:text-white/70">
              <Icon size={21} strokeWidth={1.75} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-2">
                <span className="ticket-id">{f.ticket}</span>
              </div>
              <div className="truncate text-[15px] font-bold text-ink-900 dark:text-white">{f.titel}</div>
              <div className="mt-0.5 truncate text-[13px] text-ink-500 dark:text-white/45">{f.sub}</div>
            </div>
            <Badge status={f.status} />
            {f.status === 'concept' ? (
              <a href={`/formulier/${f.id}`} className="inline-flex items-center gap-1.5 rounded bg-amber px-3 py-1.5 text-sm font-semibold text-carbon-900 hover:bg-amber-600">
                <ArrowRight size={14} /> Verder
              </a>
            ) : (
              // GET /api/formulieren/:id/export/docx
              <a href={`/api/formulieren/${f.id}/export/docx`} className="inline-flex items-center gap-1.5 rounded border border-ink-900/15 px-3 py-1.5 text-sm font-semibold text-ink-900 hover:border-amber/50 hover:text-amber dark:border-white/15 dark:text-white">
                <Download size={14} /> Word
              </a>
            )}
            <button className="text-ink-500 hover:text-ink-900 dark:text-white/40 dark:hover:text-white" aria-label={f.status === 'concept' ? 'Verwijderen' : 'Bekijken'}>
              {f.status === 'concept' ? <Trash2 size={16} /> : <Eye size={16} />}
            </button>
          </div>
        );
      })}
    </div>
  );
}
