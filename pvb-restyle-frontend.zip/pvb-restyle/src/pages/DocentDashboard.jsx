import { useEffect, useState } from 'react';
import axios from 'axios';
import { Search, Eye } from 'lucide-react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';

const cardCls =
  'rounded-lg border border-ink-900/8 bg-white transition-colors duration-200 ease-crisp dark:border-white/8 dark:bg-white/[0.03]';

export default function DocentDashboard() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    // GET /api/formulieren/alle
    axios.get('/api/formulieren/alle').then((r) => setRows(r.data)).catch(() => setRows([]));
  }, []);

  const data = rows.length
    ? rows
    : [
        { id: 1, naam: 'Bes Ternava', initials: 'BT', klas: 'SE4A', datum: '28 jun 2026', status: 'gedownload' },
        { id: 2, naam: 'Lisa Koster', initials: 'LK', klas: 'SE4A', datum: '27 jun 2026', status: 'concept' },
        { id: 3, naam: 'Deen Ali', initials: 'DA', klas: 'SE4B', datum: '26 jun 2026', status: 'ingeleverd' },
        { id: 4, naam: 'Mees Vermeer', initials: 'MV', klas: 'SE4B', datum: '24 jun 2026', status: 'gedownload' },
      ];

  const totaal = data.length;
  const gedownload = data.filter((d) => d.status === 'gedownload').length;
  const concept = data.filter((d) => d.status === 'concept').length;

  const search = (
    <div className="flex min-w-[280px] items-center gap-2.5 rounded border border-ink-900/10 bg-paper px-3.5 py-2 dark:border-white/10 dark:bg-white/[0.03]">
      <Search size={15} className="text-ink-500 dark:text-white/40" />
      <input placeholder="Zoek student of klas…" className="w-full bg-transparent text-sm text-ink-900 placeholder:text-ink-500 focus:outline-none dark:text-white dark:placeholder:text-white/40" />
    </div>
  );

  return (
    <Layout role="docent" title="Alle examenafspraken" right={search} user={{ naam: 'R. de Vries', rol: 'docent', initials: 'RV' }}>
      {/* Statistieken */}
      <div className="mb-5 flex gap-3">
        <Stat label="Totaal" value={totaal} />
        <Stat label="Gedownload" value={gedownload} accent="text-moss" />
        <Stat label="Concept" value={concept} accent="text-amber" />
      </div>

      {/* Tabel */}
      <div className={`${cardCls} overflow-hidden`}>
        <table className="w-full border-collapse text-[13.5px]">
          <thead>
            <tr>
              {['Student', 'Klas', 'Datum', 'Status', ''].map((h, i) => (
                <th key={i} className="border-b border-ink-900/8 px-5 py-3 text-left font-mono text-[10.5px] font-semibold uppercase tracking-[0.08em] text-ink-500 dark:border-white/8 dark:text-white/40">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((r) => (
              <tr key={r.id} className="border-t border-ink-900/6 dark:border-white/6">
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-[30px] w-[30px] items-center justify-center rounded-full border border-ink-900/10 font-mono text-[11px] font-semibold text-ink-700 dark:border-white/15 dark:text-white/70">
                      {r.initials}
                    </span>
                    <span className="font-semibold text-ink-900 dark:text-white">{r.naam}</span>
                  </div>
                </td>
                <td className="px-5 py-3.5 text-ink-700 dark:text-white/65">{r.klas}</td>
                <td className="px-5 py-3.5 text-ink-700 dark:text-white/65">{r.datum}</td>
                <td className="px-5 py-3.5"><Badge status={r.status} /></td>
                <td className="px-5 py-3.5 text-right">
                  <a href={`/docent/formulier/${r.id}`} className="inline-flex items-center gap-1.5 rounded border border-ink-900/12 px-3 py-1.5 text-sm font-semibold text-ink-900 hover:border-amber/50 hover:text-amber dark:border-white/15 dark:text-white">
                    <Eye size={14} /> Bekijk
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}

function Stat({ label, value, accent = 'text-ink-900 dark:text-white' }) {
  return (
    <div className={`${cardCls} flex-1 p-4`}>
      <div className="font-mono text-[10.5px] uppercase tracking-[0.1em] text-ink-500 dark:text-white/40">{label}</div>
      <div className={`mt-1 font-display text-[28px] font-bold ${accent}`}>{value}</div>
    </div>
  );
}
