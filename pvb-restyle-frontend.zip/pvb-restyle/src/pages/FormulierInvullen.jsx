import { useState } from 'react';
import { CheckCircle2, ArrowLeft, ArrowRight } from 'lucide-react';
import logo from '../assets/pvb-logo.png';
import ThemeToggle from '../components/ThemeToggle';

/**
 * 5-staps wizard. Dit scherm gebruikt een eigen sidebar (de stap-tracker) in
 * plaats van de standaard Layout-navigatie, maar behoudt dezelfde carbon-sidebar /
 * wisselend-werkvlak structuur. Stap 2 (opdracht kiezen) wordt getoond; de andere
 * stappen sluit je op dezelfde manier aan.
 *
 * Werkprocessen: B1-K1-W1 (meldingen), W2 (instrueert), W3 (devices).
 */
const STEPS = [
  { n: 1, label: 'Gegevens' },
  { n: 2, label: 'Werkproces 1' },
  { n: 3, label: 'Werkproces 2' },
  { n: 4, label: 'Werkproces 3' },
  { n: 5, label: 'Controleren' },
];

export default function FormulierInvullen() {
  const [step, setStep] = useState(2);
  const [gekozen, setGekozen] = useState(0);

  // GET /api/opdrachten → opdrachten voor het huidige werkproces
  const opdrachten = [
    { titel: 'Storingsmeldingen afhandelen', body: 'Neem meldingen aan, registreer en prioriteer ze en handel ze af binnen de SLA.' },
    { titel: 'Wachtwoordreset & accountbeheer', body: 'Verwerk toegangsaanvragen, reset accounts en documenteer de handeling.' },
    { titel: 'Hardwarestoring diagnosticeren', body: 'Onderzoek een defect device, bepaal de oorzaak en voer de reparatie uit.' },
  ];

  const inputCls =
    'w-full rounded border px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-500 border-ink-900/15 bg-white dark:text-white dark:placeholder:text-white/35 dark:border-white/15 dark:bg-white/[0.05]';

  return (
    <div className="grid h-screen grid-cols-[236px_1fr] overflow-hidden font-sans">
      {/* Stap-tracker sidebar — altijd carbon, met geperforeerde rand (ticket-motief) */}
      <aside className="relative flex flex-col bg-carbon px-3.5 py-4">
        <div className="pointer-events-none absolute right-0 top-0 h-full w-px bg-perforation" />

        <div className="flex items-center gap-3 px-2 pb-5 pt-1.5">
          <img src={logo} alt="PVB" className="h-9 w-9 rounded bg-white object-contain" />
          <div>
            <div className="font-display text-sm font-bold leading-none text-white">PVB</div>
            <div className="mt-1 font-mono text-[10px] tracking-wide text-white/40">Examenafspraken</div>
          </div>
        </div>
        <div className="px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-white/35">Nieuw formulier</div>

        <nav className="flex flex-col gap-0.5">
          {STEPS.map((s) => {
            const done = s.n < step;
            const active = s.n === step;
            return (
              <div
                key={s.n}
                className={`flex items-center gap-2.5 rounded px-2.5 py-2 text-[12.5px] ${
                  active ? 'bg-amber/15 font-semibold text-amber' : done ? 'font-semibold text-amber/80' : 'text-white/45'
                }`}
              >
                {done ? (
                  <CheckCircle2 size={16} />
                ) : (
                  <span className={`flex h-4 w-4 items-center justify-center rounded-full font-mono text-[10px] font-bold ${active ? 'bg-amber text-carbon-900' : 'border border-white/25'}`}>
                    {s.n}
                  </span>
                )}
                {s.label}
              </div>
            );
          })}
        </nav>
      </aside>

      {/* Werkvlak */}
      <div className="flex flex-col overflow-hidden bg-paper transition-colors duration-200 ease-crisp dark:bg-carbon">
        <header className="flex h-[60px] flex-shrink-0 items-center justify-between border-b border-ink-900/8 bg-white/90 px-8 backdrop-blur dark:border-white/8 dark:bg-carbon-800/70">
          <div className="flex items-center gap-3">
            <span className="ticket-id">Stap {step} / 5</span>
            <span className="font-display text-[17px] font-bold text-ink-900 dark:text-white">Werkproces 1 — opdracht kiezen</span>
          </div>
          <ThemeToggle />
        </header>

        <main className="flex-1 overflow-auto p-8">
          <p className="eyebrow">B1-K1-W1 · Handelt meldingen af</p>
          <p className="mb-4 mt-2 text-sm text-ink-700 dark:text-white/65">
            Selecteer de opdracht uit de opdrachtenbank die je uitvoert voor dit werkproces.
          </p>

          <div className="flex gap-3.5">
            {opdrachten.map((o, i) => {
              const sel = i === gekozen;
              return (
                <button
                  key={i}
                  onClick={() => setGekozen(i)}
                  className={`flex-1 rounded-lg p-[18px] text-left transition-all duration-150 ease-crisp ${
                    sel
                      ? 'border-2 border-amber bg-amber/8'
                      : 'border border-ink-900/10 bg-white dark:border-white/10 dark:bg-white/[0.03]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    {sel ? (
                      <span className="font-mono text-[10px] font-semibold uppercase tracking-wide text-amber">Gekozen</span>
                    ) : (
                      <span className="font-mono text-[10px] font-semibold uppercase tracking-wide text-ink-500 dark:text-white/40">Opdracht {i + 1}</span>
                    )}
                    {sel && <CheckCircle2 size={19} className="text-amber" />}
                  </div>
                  <div className="mt-3 text-[15px] font-bold text-ink-900 dark:text-white">{o.titel}</div>
                  <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-500 dark:text-white/45">{o.body}</div>
                </button>
              );
            })}
          </div>

          <div className="mt-5 flex gap-4">
            <div className="flex-[1.6]">
              <label className="mb-1.5 block text-xs font-semibold text-ink-900 dark:text-white">Aanvullende afspraken</label>
              <textarea rows={2} className={`${inputCls} resize-none`} placeholder="Bijv. specifieke context binnen je BPV-bedrijf…" />
            </div>
            <div className="flex-1">
              <label className="mb-1.5 block text-xs font-semibold text-ink-900 dark:text-white">Periode</label>
              <input className={inputCls} placeholder="wk 12 – wk 18" />
            </div>
          </div>
        </main>

        <footer className="flex flex-shrink-0 justify-between border-t border-ink-900/8 bg-white/90 px-8 py-4 dark:border-white/8 dark:bg-carbon-800/70">
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            className="inline-flex items-center gap-2 rounded border border-ink-900/12 px-4 py-2 text-sm font-semibold text-ink-900 hover:border-amber/50 hover:text-amber dark:border-white/15 dark:text-white"
          >
            <ArrowLeft size={17} /> Vorige
          </button>
          <button
            onClick={() => setStep((s) => Math.min(5, s + 1))}
            className="inline-flex items-center gap-2 rounded bg-amber px-4 py-2 text-sm font-semibold text-carbon-900 hover:bg-amber-600"
          >
            Volgende: Werkproces 2 <ArrowRight size={17} />
          </button>
        </footer>
      </div>
    </div>
  );
}
