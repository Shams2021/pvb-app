import { ShieldCheck, Lock, Terminal } from 'lucide-react';
import logo from '../assets/pvb-logo.png';
import ThemeToggle from '../components/ThemeToggle';

/**
 * Inlogscherm. Het linkerpaneel is altijd carbon (merk-hero), het rechterpaneel
 * wisselt licht/donker met het thema. De inlogknop start de OIDC-flow.
 */
export default function Login() {
  return (
    <div className="grid h-screen grid-cols-1 overflow-hidden font-sans md:grid-cols-[1.05fr_1fr]">
      {/* Hero — altijd donker, met een subtiel monospace "ticket"-motief */}
      <div className="relative hidden flex-col justify-between overflow-hidden bg-carbon-900 p-14 text-white md:flex">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(226,150,47,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(226,150,47,0.6) 1px, transparent 1px)',
            backgroundSize: '34px 34px',
          }}
        />

        <div className="relative flex items-center gap-3">
          <img src={logo} alt="PVB" className="h-11 w-11 rounded bg-white object-contain" />
          <div>
            <div className="font-display text-base font-bold leading-tight">PVB Examenafspraken</div>
            <div className="text-xs text-white/45">Techniek College Rotterdam</div>
          </div>
        </div>

        <div className="relative">
          <p className="eyebrow">Proeve van bekwaamheid · B1-K1</p>
          <h2 className="mb-3.5 mt-2.5 font-display text-[34px] font-bold leading-tight tracking-tight">
            Van formulier naar
            <br />
            <span className="text-amber">examenklaar.</span>
          </h2>
          <p className="max-w-sm text-sm leading-relaxed text-white/65">
            Stel je examenafspraakformulier op voor drie werkprocessen en download
            het officiële Word-document.
          </p>
        </div>

        <div className="relative flex items-center gap-7 font-mono">
          <div>
            <div className="text-2xl font-semibold text-amber">3</div>
            <div className="text-[11px] uppercase tracking-[0.1em] text-white/45">werkprocessen</div>
          </div>
          <div>
            <div className="text-2xl font-semibold text-amber">~10<span className="text-sm">min</span></div>
            <div className="text-[11px] uppercase tracking-[0.1em] text-white/45">invultijd</div>
          </div>
          <Terminal size={22} strokeWidth={1.5} className="ml-auto text-white/25" />
        </div>
      </div>

      {/* Inlogpaneel — wisselt licht/donker */}
      <div className="flex flex-col bg-paper transition-colors duration-200 ease-crisp dark:bg-carbon">
        <div className="flex h-[60px] items-center justify-end px-7">
          <ThemeToggle />
        </div>
        <div className="flex flex-1 items-center justify-center px-12 pb-12">
          <div className="w-full max-w-sm text-center">
            <img src={logo} alt="PVB" className="mx-auto mb-3 h-[72px] w-[72px] rounded-lg object-contain" />
            <p className="eyebrow">Welkom</p>
            <h2 className="mb-2 mt-1.5 font-display text-[26px] font-bold tracking-tight text-ink-900 dark:text-white">
              Inloggen
            </h2>
            <p className="mb-7 text-sm leading-relaxed text-ink-700 dark:text-white/70">
              Gebruik je schoolaccount om verder te gaan.
            </p>

            {/* OIDC-login — verwijst naar Authentik */}
            <a
              href="/api/auth/login"
              className="flex w-full items-center justify-center gap-2 rounded bg-amber px-5 py-3.5 font-semibold text-carbon-900 transition-all duration-150 ease-crisp hover:bg-amber-600"
            >
              <ShieldCheck size={19} strokeWidth={1.75} /> Inloggen met schoolaccount
            </a>

            <div className="mt-5 flex items-center justify-center gap-2 font-mono text-[11px] text-ink-500 dark:text-white/45">
              <Lock size={13} strokeWidth={1.75} /> beveiligd via authentik sso
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
