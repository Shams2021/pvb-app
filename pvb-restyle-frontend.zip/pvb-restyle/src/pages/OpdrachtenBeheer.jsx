import { useEffect, useState } from 'react';
import axios from 'axios';
import { Plus, Ticket, KeyRound, Wrench, Pencil, Trash2 } from 'lucide-react';
import Layout from '../components/Layout';
import Badge from '../components/Badge';

const cardCls =
  'rounded-lg border border-ink-900/8 bg-white p-4 transition-colors duration-200 ease-crisp dark:border-white/8 dark:bg-white/[0.03]';

const WERKPROCESSEN = [
  { key: 'W1', label: 'W1 · Handelt meldingen af' },
  { key: 'W2', label: 'W2 · Instrueert gebruikers' },
  { key: 'W3', label: 'W3 · Beheert devices' },
];

const ICONS = [Ticket, KeyRound, Wrench];

export default function OpdrachtenBeheer() {
  const [tab, setTab] = useState('W1');
  const [opdrachten, setOpdrachten] = useState([]);

  useEffect(() => {
    // GET /api/opdrachten/beheer (docent: incl. inactieve)
    axios.get('/api/opdrachten/beheer').then((r) => setOpdrachten(r.data)).catch(() => setOpdrachten([]));
  }, []);

  const sample = [
    { titel: 'Storingsmeldingen afhandelen', omschrijving: 'Neem meldingen aan, registreer en handel ze af binnen de SLA. · 2 subvragen', is_actief: true },
    { titel: 'Wachtwoordreset & accountbeheer', omschrijving: 'Verwerk toegangsaanvragen, reset accounts en documenteer de handeling. · 3 subvragen', is_actief: true },
    { titel: 'Hardwarestoring diagnosticeren', omschrijving: 'Onderzoek een defect device en voer of plan de reparatie. · 2 subvragen', is_actief: false },
  ];
  const rows = opdrachten.length ? opdrachten.filter((o) => o.werkproces === tab) : sample;

  const NieuwBtn = (
    <button className="inline-flex items-center gap-2 rounded bg-amber px-4 py-2 text-sm font-semibold text-carbon-900 hover:bg-amber-600">
      <Plus size={17} strokeWidth={2} /> Nieuwe opdracht
    </button>
  );

  return (
    <Layout role="docent" title="Opdrachtenbank" right={NieuwBtn} user={{ naam: 'R. de Vries', rol: 'docent', initials: 'RV' }}>
      {/* Tabs per werkproces */}
      <div className="mb-5 flex gap-2 border-b border-ink-900/8 dark:border-white/8">
        {WERKPROCESSEN.map((w) => (
          <button
            key={w.key}
            onClick={() => setTab(w.key)}
            className={`px-4 py-2.5 text-sm transition-colors ${
              tab === w.key
                ? 'border-b-2 border-amber font-semibold text-ink-900 dark:text-white'
                : 'font-medium text-ink-500 dark:text-white/50'
            }`}
          >
            {w.label} <span className="font-mono text-ink-500 dark:text-white/40">3</span>
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3">
        {rows.map((o, i) => {
          const Icon = ICONS[i % ICONS.length];
          return (
            <div key={i} className={`${cardCls} flex items-center gap-4 ${!o.is_actief ? 'opacity-60' : ''}`}>
              <span className="flex h-9 w-9 items-center justify-center rounded border border-ink-900/10 text-ink-700 dark:border-white/10 dark:text-white/70">
                <Icon size={18} strokeWidth={1.75} />
              </span>
              <div className="flex-1">
                <div className="text-[14.5px] font-bold text-ink-900 dark:text-white">{o.titel}</div>
                <div className="mt-0.5 text-[12.5px] text-ink-500 dark:text-white/45">{o.omschrijving}</div>
              </div>
              <Badge status={o.is_actief ? 'actief' : 'inactief'} />
              <button className="text-ink-500 hover:text-ink-900 dark:text-white/45 dark:hover:text-white" aria-label="Bewerken"><Pencil size={15} /></button>
              <button className="text-ink-500 hover:text-ink-900 dark:text-white/45 dark:hover:text-white" aria-label="Verwijderen"><Trash2 size={15} /></button>
            </div>
          );
        })}
      </div>
    </Layout>
  );
}
