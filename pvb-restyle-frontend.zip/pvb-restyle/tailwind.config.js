/** @type {import('tailwindcss').Config} */
export default {
  // 'class' strategy = we toggle dark mode by adding/removing `dark` on <html>.
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // PVB Werkbank palette — origineel, geïnspireerd op servicedesk/ticket-systemen.
        carbon: { DEFAULT: '#181C1E', 900: '#101314', 800: '#20262A' },
        paper: '#EEF1EE',
        ink: { 900: '#1B211F', 700: '#3E4A46', 500: '#68746F' },
        amber: { DEFAULT: '#E2962F', 600: '#C97F1E' },
        moss: '#4C8C5B',
        rust: '#B85C38',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['"IBM Plex Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      transitionTimingFunction: {
        // vlakke, precieze ease-out — geen bounce
        crisp: 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
      backgroundImage: {
        // subtiele stippen-textuur voor de sidebar, als een geperforeerde ticketrand
        perforation:
          'repeating-linear-gradient(to bottom, transparent 0 6px, rgba(255,255,255,0.12) 6px 7px)',
      },
    },
  },
  plugins: [],
};
